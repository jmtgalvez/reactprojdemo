import React from 'react';
import '../css/footer.css';

function Footer() {
    return (
        <footer className='classFooter'>
            <p>This is a sample footer.</p>
        </footer> 
    );
}

export default Footer;