const BoardData = [
    {
        id: 1,
        category:'Curent Events',
        post: 'Our current event for the day'
    },
    {
        id: 2,
        category: 'Announcement',
        post: "We have an announcment"
    },
    {
        id: 3,
        category: 'Quotes of the Day',
        post: 'Quotable quotes here'
    },
    {
        id: 4,
        post: 'We will keep you posted'
    },
    {
        id: 5,
        category: "Don't overthink"
    }
]

export default BoardData;